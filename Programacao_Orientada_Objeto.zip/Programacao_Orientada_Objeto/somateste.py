class fazSoma:
    array1 = [0, 0]
    array2 = [0, 0]
    def __init__(self, array1):
        self.array1 = array1
        self.array2 = [-10, -20]

    def somma(self):
        print(sum(self.array1))
        print(sum(self.array2))


print(fazSoma([10,20]).array1)