class Pessoa:
    def __init__(self, nome, morada, nif):
        self.nome = nome
        self.morada = morada
        self.nif = nif


class Condutor(Pessoa):
    def __init__(self, nome, morada, nif, numero_carta, idade):
        super().__init__(nome, morada, nif)
        self.__numero_carta = numero_carta
        self.__idade = idade


class Motorista(Condutor):
    def __init__(self, nome, morada, nif, numero_carta, idade, anos_condutor, ordenado_base):
        super().__init__(nome, morada, nif, numero_carta, idade)
        self.anos_condutor = anos_condutor
        self.ordenado_base = ordenado_base

    def calcular_salario(self, imposto):
        salario_liquido = self.ordenado_base * (1 - (imposto / 100))
        salario_liquido_comissao = salario_liquido + (salario_liquido * (1 - (self.anos_condutor / 100)))
        return salario_liquido_comissao


class Viagem(Motorista):

    numero_viagem = 0

    def __init__(self, nome, morada, nif, numero_carta, idade, anos_condutor, ordenado_base, partida, chegada, data):
        super().__init__(nome, morada, nif, numero_carta, idade, anos_condutor, ordenado_base)
        self.partida = partida
        self.chegada = chegada
        self.data = data
        Viagem.numero_viagem += 1
        self.numero_viagem = Viagem.numero_viagem

    def __repr__(self):
        return f"""A viagem {self.numero_viagem}, entre a cidade {self.partida} e cidade {self.chegada}
               foi realizada pelo motorista {self.nome} no dia {self.data}"""


if __name__ == '__main__':
    m1 = Motorista("Joao", "Rua nao sei que", 123, "234-A", 50, 30, 1400)
    m2 = Motorista("Manuel", "Av nao sei que", 321, "134-B", 27, 3, 1000)
    print(f"O motorista {m1.nome}, tem um salario de {m1.calcular_salario(30)}")
    v1 = Viagem("Joao", "Rua nao sei que", 123, "234-A", 50, 30, 1400, "Lisboa", "Faro", "6/12/2021")
    v2 = Viagem("Manuel", "Av nao sei que", 321, "134-B", 27, 3, 1000, "Albufeira", "Faro", "7/12/2021")
    print(v1)
    print(v2)
