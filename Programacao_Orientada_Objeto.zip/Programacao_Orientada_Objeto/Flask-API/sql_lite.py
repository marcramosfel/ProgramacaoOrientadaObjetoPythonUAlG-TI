import sqlite3

class LigacaoServer:
    '''
    preparacao da ligacao ao servidor sqlite
    '''
    def __init__(self, db):
        try:
            self.conn = sqlite3.connect(db)
            self.cursor = self.conn.cursor()
        except:
            print("Nao possivel ligar ao servidor sqlite")


    def createTables(self):
        '''
        método que cria as tabelas
        '''
        sql = '''
        create table if not exists Location
        (
            idLocation integer
                constraint Location_pk
                    primary key autoincrement,
            name TEXT not null,
            description text not null
        );


        create table if not exists Unit
        (
            unit text
                constraint Unit_pk
                    primary key,
            description text not null
        );

        create table if not exists Sensor
        (
            idSensor integer
                constraint Sensor_pk
                    primary key autoincrement,
            idLocation integer not null
                constraint Sensor_Location_idLocation_fk
                    references Location
                        on update cascade on delete cascade,
            name text not null,
            unit text not null
                constraint Sensor_Unit_unit_fk
                    references Unit
                        on update cascade on delete cascade
        );

        create table if not exists Reading
        (
            idReading integer
                constraint Reading_pk
                    primary key autoincrement,
            idSensor integer
                constraint Reading_Sensor_idSensor_fk
                    references Sensor
                        on update cascade on delete cascade,
            timestamp datetime default CURRENT_TIMESTAMP,
            value real not null
        );


        create table if not exists Alert
        (
            idAlert integer
                constraint Alert_pk
                    primary key autoincrement,
            idSensor integer
                constraint Alert_Sensor_idSensor_fk
                    references Sensor
                        on update cascade on delete cascade,
            description text not null,
            cleared integer

        )
        '''
        self.cursor.executescript(sql)



    def carregaTabelaLocation(self, data):
        # prepare the sql query for the new location
        sql = '''
            INSERT INTO Location 
                (name, description) 
            VALUES 
                (?, ?)
                '''

        # execute the sql query
        self.cursor.execute(sql, data)
        self.conn.commit()

    def removeDuplicadosLocation(self):

        #devolve a coluna CNT com a contagem de registos com o mesmo Name
        #sql = '''
        #    SELECT *, count (*) as CNT from location group by name
        #    '''

        sql = '''
            DELETE from location where idlocation not in 
            (select min(idLocation) from location group by name)
            '''
        self.cursor.execute(sql)
        self.conn.commit()

    def listarLocation(self):
        '''
        mostra info da tabela location organizada
        '''

        sql = '''
            select * from location
            '''
        self.cursor.execute(sql)

        print(self.cursor.fetchall())
        for registo in self.cursor.fetchall():
            print("IDlocation: {} \n\t Name: {}\n\t Description: {} \n\t ".format(registo[1], registo[2], registo[3]))
        #for (idLocation, Name, description) in self.cursor:
        #    print("IDlocation: {} \n\t Name: {}\n\t Description: {} \n\t ".format(idLocation, Name, description))

    def close(self):
        self.conn.close()


if __name__ == "__main__":

    # se não existir a base de dados (ficheiro) exemplo.db será criada
    L = LigacaoServer('sensors.db')
    servers = ['SERVER1', 'SERVER2', 'SERVER3', 'SERVER4']
    labs = ['SERVER1@lab1', 'SERVER2@lab1', 'SERVER3@lab2','SERVER4@lab2']

    L.createTables()
    for data in list(zip(servers,labs)):
        L.carregaTabelaLocation(data)

    L.listarLocation()


    L.removeDuplicadosLocation() #usado para remover duplicados

    L.listarLocation()

    L.close()