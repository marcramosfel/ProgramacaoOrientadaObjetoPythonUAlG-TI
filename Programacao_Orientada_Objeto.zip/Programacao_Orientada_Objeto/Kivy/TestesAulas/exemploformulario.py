from kivy.app import App
from kivy.uix.label import Label
from kivy.uix.gridlayout import GridLayout
from kivy.uix.spinner import Spinner
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.checkbox import CheckBox
from kivy.uix.progressbar import ProgressBar

utilizadores = [
    {'nome':'ze', 'email': 'ze@ualg.pt'},
    {'nome':'quim', 'email': 'quim@ualg.pt'},
    {'nome':'mario', 'email': 'mario@ualg.pt'},
    {'nome':'joao', 'email': 'joao@ualg.pt'}
]

class Formulario(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.idx = 0
        self.orientation = 'vertical'
        grid = GridLayout(cols=2)

        label1 = Label(text='Nome')
        self.caixadetexto1 = TextInput(multiline=False)

        label2 = Label(text='Email')
        self.caixadetexto2 = TextInput(multiline=False)

        label3 = Label(text='Tem Carro')
        self.checkbox1 =CheckBox(color=[0,300,0,2])

        label4 = Label(text='País')
        self.spinner = Spinner(
            text='Portugal',
            values=('Portugal', 'Espanha', 'França', 'Brasil', 'Alemanha'),
        )
        box_sexo = GridLayout(cols=2)
        label5 = Label(text='Sexo')

        label_masc = Label(text='Masculino')
        label_feminino = Label(text='Feminino')
        self.checkbox9 = CheckBox(group='sexo')
        self.checkbox10 = CheckBox(group='sexo')
        box_sexo.add_widget(label_masc)
        box_sexo.add_widget(self.checkbox9)
        box_sexo.add_widget(label_feminino)
        box_sexo.add_widget(self.checkbox10)

        box_buttons = BoxLayout(orientation='horizontal')

        self.bt_novo = Button(text='Novo')
        self.bt_novo.bind(on_release=self.botao_clicado)
        self.bt_apaga = Button(text='Apaga')
        self.bt_apaga.bind(on_release=self.botao_clicado)
        self.bt_grava = Button(text='Grava')
        self.bt_grava.bind(on_release=self.botao_clicado)
        self.bt_anterior = Button(text='Anterior')
        self.bt_anterior.bind(on_release=self.botao_clicado)
        self.bt_proximo = Button(text='Proximo')
        self.bt_proximo.bind(on_release=self.botao_clicado)



        for widget in [label1, self.caixadetexto1, label2, self.caixadetexto2, label5, box_sexo, label3, self.checkbox1, label4, self.spinner]:
            grid.add_widget(widget)
        self.add_widget(grid)


        for buttons in [self.bt_novo, self.bt_apaga, self.bt_grava,self.bt_anterior, self.bt_proximo]:
            box_buttons.add_widget(buttons)
        self.add_widget(box_buttons)
        self.pb = ProgressBar(max=100)
        self.add_widget(self.pb)


    def botao_clicado(self, instance):
        if instance == self.bt_proximo:
            if self.idx>=0:
                self.idx += 1
                if self.idx >= len(utilizadores):
                    self.idx = 0
        elif instance == self.bt_anterior:
            if self.idx>=0:
                self.idx -= 1
                if self.idx < 0:
                    self.idx = len(utilizadores)-1
        elif instance == self.bt_novo:
            novo = {'nome': '??', 'email': '??'}
            utilizadores.append(novo)
            self.idx = len(utilizadores)-1
        elif instance == self.bt_apaga:
            if len(utilizadores)>0:
                del utilizadores[self.idx]
                self.idx = len(utilizadores)-1
        elif instance == self.bt_grava:
            if self.idx>=0:
                utilizadores[self.idx]['nome'] = self.caixadetexto1.text
                utilizadores[self.idx]['email'] = self.caixadetexto2.text

        else:
            print("instancia nao reconhecida")

        self.preenche_dados()


    def preenche_dados(self):
        if len(utilizadores) > 0:
            self.caixadetexto1.text = utilizadores[self.idx]['nome']
            self.caixadetexto2.text = utilizadores[self.idx]['email']
            self.pb.value = (self.idx +1)/ len(utilizadores) * 100
        else:
            self.caixadetexto1.text = '---'
            self.caixadetexto2.text = '---'
            self.pb.value = 0


class MyApp(App):
    def build(self):
        return Formulario()

MyApp().run()