from kivy.app import App
from kivy.uix.label import Label
from kivy.uix.gridlayout import GridLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.checkbox import CheckBox
from kivy.uix.progressbar import ProgressBar


def callback(instance):
    print(f'DEU BOM, O BOTÃO > {instance.text} < ESTÁ SENDO PRESSIONADO!')

def on_checkbox_active(lugar_guardada_memoria, estado):
    if estado:
        print('the checkbox', lugar_guardada_memoria, 'esta ativa' )
    else:
        print('the checkbox', lugar_guardada_memoria, 'nao esta ativa')


class LoginScreen(GridLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.cols = 1

        # self.row_force_default = True
        # self.row_default_height = 40
        self.orientation = 'tb-lr'
        label1 = Label(text='Nome')
        caixadetexto1 = TextInput(multiline=False)

        button1 = Button(text='ok')
        button1.bind(on_press = callback)
        button2 = Button(text='cancelar')
        button2.bind(on_press=callback)
        box = BoxLayout(orientation='vertical')
        box.add_widget(button1)
        box.add_widget(button2)
        checkbox = CheckBox()
        checkbox.bind(active=on_checkbox_active)
        pb = ProgressBar(max=1000)
        pb.value = 750
        # buttons = BoxLayout(self.add_widget(button1), self.add_widget(button2))
        for wdiget in [label1, caixadetexto1, box, checkbox, pb]:
            self.add_widget(wdiget)

        """self.add_widget(label1)
        self.add_widget(caixadetexto1)
        self.add_widget(label2)
        self.add_widget(caixadetexto2)"""

class MyApp(App):
    def build(self):
        return LoginScreen()

MyApp().run()