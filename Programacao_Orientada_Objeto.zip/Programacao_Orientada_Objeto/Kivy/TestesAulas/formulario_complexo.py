from kivy.app import App
from kivy.uix.label import Label
from kivy.uix.gridlayout import GridLayout
from kivy.uix.spinner import Spinner
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.checkbox import CheckBox
from kivy.uix.progressbar import ProgressBar


class Pessoa:
    def __init__(self, nome, email, carro, nacionalidade, sexo): #sexo true para home false para mulher
        self.nome = nome
        self.email = email
        self.carro = carro
        self.nacionalidade = nacionalidade
        self.sexo = sexo

class FormularioWidget(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
        self.idx = 0
        self.utilizadores = [Pessoa('ze',  'ze@ualg.pt', True, 'Portugal', True),
                            Pessoa('quim', 'quim@ualg.pt', False, 'Espanha', True),
                            Pessoa('marcos', 'marcos@ualg.pt', True, 'França', True),
                            Pessoa('mario', 'mario@ualg.pt', False, 'Brasil', True),
                            Pessoa('ana', 'ana@ualg.pt', True, 'Alemanha', False)
                             ]
        self.preenche_dados()

    def bt_proximo(self):
        if self.idx >= 0:
            self.idx += 1
            if self.idx >= len(self.utilizadores):
                self.idx = 0
        self.preenche_dados()
        
    def bt_anterior(self):
        if self.idx >= 0:
            self.idx -= 1
            if self.idx < 0:
                self.idx = len(self.utilizadores) - 1
        self.preenche_dados()
        
    def bt_novo(self):
        novo = Pessoa('??', '??', False, 'Nacioanalidade', sexo=None)
        self.utilizadores.append(novo)
        self.idx = len(self.utilizadores) - 1
        self.preenche_dados()

    def bt_apaga(self):
        if len(self.utilizadores) > 0:
            del self.utilizadores[self.idx]
            self.idx = len(self.utilizadores) - 1
        self.preenche_dados()


    def bt_grava(self):
        if self.idx >= 0:
            self.utilizadores[self.idx].nome = self.ids.nome.text
            self.utilizadores[self.idx].email = self.ids.email.text
            self.utilizadores[self.idx].carro = self.ids.carro.active
            self.utilizadores[self.idx].nacionalidade = self.ids.nacionalidade.text
            if self.ids.masculino.active:
                self.utilizadores[self.idx].sexo = True
            elif self.ids.feminino.active:
                self.utilizadores[self.idx].sexo = False


    def preenche_dados(self):
        print(self.idx)
        if len(self.utilizadores) > 0:
            self.ids.nome.text = self.utilizadores[self.idx].nome
            self.ids.email.text = self.utilizadores[self.idx].email
            self.ids.carro.active = self.utilizadores[self.idx].carro
            self.ids.pb.value = (self.idx + 1) / len(self.utilizadores) * 100
            self.ids.nacionalidade.text = self.utilizadores[self.idx].nacionalidade
            if self.utilizadores[self.idx].sexo:
                self.ids.masculino.active = self.utilizadores[self.idx].sexo
            else:
                self.ids.feminino.active = True
        else:
            self.ids.nome.text = '---'
            self.ids.email.text = '---'
            self.pb.value = 0


class MyFormularyApp(App):
    def build(self):
        return FormularioWidget()


MyFormularyApp().run()
