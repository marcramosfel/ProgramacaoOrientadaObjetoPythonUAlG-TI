from kivy.app import App
from kivy.uix.label import Label
from kivy.uix.gridlayout import GridLayout
from kivy.uix.textinput import TextInput


class LoginScreen(GridLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.cols = 2
        self.row_force_default = True
        self.row_default_height = 40
        self.orientation = 'tb-lr'
        label1 = Label(text='Nome', size_hint_x=None, width=100)
        caixadetexto1 = TextInput(multiline=False)

        label2 = Label(text='Password', size_hint_x=None, width=100)
        caixadetexto2= TextInput(password=True,  multiline=False)

        for wdiget in [label1, caixadetexto1, label2, caixadetexto2]:
            self.add_widget(wdiget)

        """self.add_widget(label1)
        self.add_widget(caixadetexto1)
        self.add_widget(label2)
        self.add_widget(caixadetexto2)"""

class MyApp(App):
    def build(self):
        return LoginScreen()

MyApp().run()