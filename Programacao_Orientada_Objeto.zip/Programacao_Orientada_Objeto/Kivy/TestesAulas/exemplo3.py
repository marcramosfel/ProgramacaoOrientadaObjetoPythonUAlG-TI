from kivy.app import App
from kivy.uix.label import Label
from kivy.uix.gridlayout import GridLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout



class LoginScreen(GridLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.cols = 3

        self.row_force_default = True
        self.row_default_height = 40
        self.orientation = 'tb-lr'
        label1 = Label(text='Nome')
        caixadetexto1 = TextInput(multiline=False)

        button1 = Button(text='ok')
        button2 = Button(text='cancelar')
        box = BoxLayout(orientation='vertical')
        box.add_widget(button1)
        box.add_widget(button2)
        # buttons = BoxLayout(self.add_widget(button1), self.add_widget(button2))
        for wdiget in [label1, caixadetexto1, box]:
            self.add_widget(wdiget)

        """self.add_widget(label1)
        self.add_widget(caixadetexto1)
        self.add_widget(label2)
        self.add_widget(caixadetexto2)"""

class MyApp(App):
    def build(self):
        return LoginScreen()

MyApp().run()