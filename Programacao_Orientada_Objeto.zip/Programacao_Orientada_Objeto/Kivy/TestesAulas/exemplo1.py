from kivy.app import App
from kivy.uix.label import Label
from kivy.utils import *



class MyApp(App):
    def build(self):
        text = 'TESTANDO SEM BOLD E PRETO'
        return Label(text = '[b][color=ff3333]HELLO[/color] [color=3333ff]WORLD[/color][/b]   ' + escape_markup(text), markup=True)

MyApp().run()